<?php
session_start();
$db = mysqli_connect('localhost', 'root', '', 'online_bus') or die("Could not connect to Database");

// Fetch dynamic source and destination options
$src_options = '';
$to_options = '';

$src_query = "SELECT DISTINCT source FROM bus_details WHERE source IS NOT NULL AND source != ''";
$to_query = "SELECT DISTINCT destination FROM bus_details WHERE destination IS NOT NULL AND destination != ''";

$src_result = mysqli_query($db, $src_query);
$to_result = mysqli_query($db, $to_query);

while ($row = mysqli_fetch_assoc($src_result)) {
    $src = htmlspecialchars($row['source']);
    $src_options .= "<option value=\"$src\">$src</option>";
}

while ($row = mysqli_fetch_assoc($to_result)) {
    $to = htmlspecialchars($row['destination']);
    $to_options .= "<option value=\"$to\">$to</option>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page</title>
    <style>
        * {
            margin: 0%;
            padding: 0%;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
        }

        h1 {
            background-color: black;
            opacity: 0.6;
            height: 105px;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100vw;
            color: wheat;
        }

        .firstform {
            padding: 25px;
            width: max-content;
            margin: 100px auto;
            font-size: 20px;
            border: 1px solid red;
        }

        #src_id,
        #to_id,
        #date_id {
            padding: 10px;
            font-size: 16px;
            width: 100%;
            margin-bottom: 25px;
            font-family: auto;
        }

        .submit {
            padding: 10px;
            background-color: #666666;
            border: none;
            color: white;
            font-size: 17px;
            cursor: pointer;
            border-radius: 3px;
        }

        input[type="submit"]:hover {
            background-color: black;
            color: wheat;
        }

        .secondform {
            padding: 25px;
            width: max-content;
            margin: auto;
            font-size: 20px;
            border: 1px solid red;
            margin-bottom: 25px;
            position: relative;
            top: -58px;
        }

        th,
        td {
            padding: 5px;
            border: none;
        }

        .lastbutton {
            margin: auto;
            display: block;
            padding: 11px;
            font-size: 19px;
            background-color: #666666;
            border: none;
            color: white;
            cursor: pointer;
            border-radius: 3px;
        }

        .contact-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #666666;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .contact-btn:hover {
            background-color: black;
            color: wheat;
        }
    </style>
</head>

<body>
    <center>
        <h1><u>Ticket Reservations</u></h1>
    </center>

    <!-- Contact Button -->
    <a href="contact.php"><button class="contact-btn">Contact Us</button></a>

    <!-- Reservation Form -->
    <form action="" method="post" class="firstform">
        from:
        <select name="src_name" id="src_id" required>
            <?= $src_options ?>
        </select><br>

        to:
        <select name="to_name" id="to_id" required>
            <?= $to_options ?>
        </select><br><br>

        Date of journey:
        <input type="date" name="date_name" id="date_id" required><br><br>

        <input name="submit" type="submit" value="GET DETAILS" class="submit">
    </form>

    <!-- Bus Details Form -->
    <form action="passenger info.php" method="post" class="secondform">
        <?php
        if (isset($_POST['submit'])) {
            $frm = $_POST['src_name'];
            $to = $_POST['to_name'];

            $_SESSION["frm"] = $frm;
            $_SESSION["to"] = $to;
            $_SESSION["dt"] = $_POST['date_name'];

            $query = "SELECT * FROM bus_details WHERE source='$frm' AND destination='$to'";
            $result = mysqli_query($db, $query) or die("Could not execute query");

            if (mysqli_num_rows($result) > 0) {
                echo '<table style="border: 2px solid blue;">
                    <tr>
                        <th>BUS NAME</th>
                        <th>FARE</th>
                        <th>VACANT SEATS</th>
                        <th>SELECT</th>
                    </tr>';

                while ($row = mysqli_fetch_row($result)) {
                    $bus_name = $row[0];
                    $fare = $row[3];
                    $seats = $row[4];

                    $value = $bus_name . '|' . $fare;

                    echo "<tr>
                            <td>$bus_name</td>
                            <td align='center'>$fare</td>
                            <td align='center'>$seats</td>
                            <td align='center'><input type='radio' name='bus_choice' value='$value' required></td>
                          </tr>";
                }

                echo '</table>';
            } else {
                echo "<p>No buses found for this route.</p>";
            }
        }
        ?>
        <br><br>
        <input type="submit" value="Submit" class="lastbutton">
    </form>
</body>

</html>
