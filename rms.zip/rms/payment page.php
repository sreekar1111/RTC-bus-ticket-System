<?php
// Start session only if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['myName'])) {
    // Connect to the database
    $db = mysqli_connect('localhost', 'root', '', 'online_bus') or die("Could not connect to Database");

    // Retrieve and sanitize payment form inputs
    $name = mysqli_real_escape_string($db, $_POST['myName'] ?? '');
    $gender = mysqli_real_escape_string($db, $_POST['myGndr'] ?? '');
    $address = mysqli_real_escape_string($db, $_POST['myText'] ?? '');
    $email = mysqli_real_escape_string($db, $_POST['email_name'] ?? '');
    $pincode = mysqli_real_escape_string($db, $_POST['pin_name'] ?? '');
    $cardType = mysqli_real_escape_string($db, $_POST['myCard'] ?? '');
    $cardNumber = mysqli_real_escape_string($db, $_POST['cardNumber_name'] ?? '');
    $expiryDate = mysqli_real_escape_string($db, $_POST['exDate_nam'] ?? '');
    $cvv = mysqli_real_escape_string($db, $_POST['cvvPass_name'] ?? '');

    // Insert payment details into the payments table
    $query = "INSERT INTO payments (name, gender, address, email, pincode, card_type, card_number, expiry_date, cvv)
              VALUES ('$name', '$gender', '$address', '$email', '$pincode', '$cardType', '$cardNumber', '$expiryDate', '$cvv')";
    $result = mysqli_query($db, $query);

    if (!$result) {
        die("Database insert failed: " . mysqli_error($db));
    }

    // Update bus seat availability and store passenger details if provided.
    if (isset($_POST['num_name']) && isset($_SESSION['bsnm'])) {
        $num_seats = intval($_POST['num_name']);
        $_SESSION['no'] = $num_seats;

        // Store passenger information into session variables
        $a = 1;
        while ($a <= $num_seats) {
            if (isset($_POST['col2_' . $a])) {
                $_SESSION['pname' . $a] = $_POST['col2_' . $a];
            }
            if (isset($_POST['col3_' . $a])) {
                $_SESSION['pconno' . $a] = $_POST['col3_' . $a];
            }
            if (isset($_POST['col4_' . $a])) {
                $_SESSION['page' . $a] = $_POST['col4_' . $a];
            }
            $a++;
        }

        $_SESSION["hdcunt"] = $num_seats;
        $bus_name = mysqli_real_escape_string($db, $_SESSION['bsnm']);
        $update_query = "UPDATE bus_details SET seats_available = seats_available - $num_seats WHERE bus_name = '$bus_name'";
        $update_result = mysqli_query($db, $update_query);
        if (!$update_result) {
            die("Could not execute update query: " . mysqli_error($db));
        }
    }

    // Redirect to the ticket page after successful payment processing
    header("Location: ticket page.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Payment Gateway</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7f6;
        }
        h2.mainhead {
            background-color: black;
            opacity: 0.6;
            height: 105px;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100vw;
            color: wheat;
            margin-bottom: 20px;
        }
        .contuner {
            border: 1px solid #6763635c;
            width: 51%;
            margin: 20px auto;
            padding: 15px;
            border-radius: 10px;
            background-color: #fff;
        }
        .contuner h3 {
            margin-bottom: 10px;
            color: #333;
        }
        input,
        textarea,
        select {
            width: 100%;
            padding: 8px;
            margin: 5px 0 15px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="radio"] {
            width: auto;
        }
        fieldset {
            padding: 5px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        fieldset legend {
            padding: 0 5px;
        }
        input[type="submit"],
        input[type="reset"] {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            background-color: #4CAF50;
            color: #fff;
            cursor: pointer;
            font-size: 16px;
            margin-right: 10px;
        }
        input[type="submit"]:hover,
        input[type="reset"]:hover {
            background-color: #45a049;
        }
    </style>
    <script>
        function validate() {
            var pin = document.getElementById("pin_id").value;
            var cardNumber = document.getElementById("cardNumber_id").value;
            var expDate = document.getElementById("exDate_id").value;
            var cvv = document.getElementById("cvvPass_id").value;
            
            // Check if pin, card number, and CVV are numeric
            if (isNaN(pin)) {
                alert("Please enter a valid pincode (numeric value).");
                return false;
            }
            if (isNaN(cardNumber)) {
                alert("Please enter a valid card number (numeric value).");
                return false;
            }
            if (isNaN(cvv)) {
                alert("Please enter a valid CVV (numeric value).");
                return false;
            }
            
            // Check expiry date is in the future
            var currentDate = new Date();
            var day = ("0" + currentDate.getDate()).slice(-2);
            var month = ("0" + (currentDate.getMonth() + 1)).slice(-2);
            var year = currentDate.getFullYear();
            var currentFormatted = parseInt(year.toString() + month.toString() + day.toString());

            var expFormatted = parseInt(expDate.replace(/-/g, ''));
            if (expFormatted < currentFormatted) {
                alert("Please enter a valid card expiry date (must be in the future).");
                return false;
            }
            return true;
        }
    </script>
</head>

<body>
    <h2 class="mainhead"><b><u>Payment Form</u></b></h2>

    <div class="contuner">
        <h3>Contact Information</h3>
        <form action="" autocomplete="off" method="post" onsubmit="return validate()">
            <div>
                Name: <input type="text" name="myName" required placeholder="Type your name" />
            </div>
            <div>
                <fieldset>
                    <legend>Gender</legend>
                    MALE <input type="radio" name="myGndr" value="Male" required /> &nbsp;&nbsp;
                    FEMALE <input type="radio" name="myGndr" value="Female" />
                </fieldset>
            </div>
            <div>
                <label for="address">Address</label>
                <textarea name="myText" id="address" cols="30" rows="3" placeholder="Enter your address"></textarea>
            </div>
            <div>
                Email: <input type="email" name="email_name" id="email_id" required placeholder="example@gmail.com" />
            </div>
            <div>
                Pincode: <input type="number" name="pin_name" id="pin_id" required placeholder="111111" minlength="6"
                    maxlength="6" />
            </div>
            <hr />
            <h3>Payment Info</h3>
            <div>
                Card type:
                <select name="myCard" required>
                    <option value="">--Select card type--</option>
                    <option value="masterCard">Master Card</option>
                    <option value="debitCard">Debit Card</option>
                </select>
            </div>
            <div>
                Card Number: <input type="number" name="cardNumber_name" id="cardNumber_id" required
                    placeholder="1111222233334444" minlength="16" maxlength="16" />
            </div>
            <div>
                Expiry Date: <input type="date" name="exDate_nam" id="exDate_id" required />
            </div>
            <div>
                CVV: <input type="password" name="cvvPass_name" id="cvvPass_id" required placeholder="123" minlength="3"
                    maxlength="3" />
            </div>
            <div>
                <input type="submit" value="Pay Now" />
                <input type="reset" value="Reset" />
            </div>
        </form>
    </div>
</body>

</html>
