<?php
session_start();

if (isset($_POST['bus_choice'])) {
    list($bus_name, $fare) = explode('|', $_POST['bus_choice']);

    $_SESSION["bsnm"] = $bus_name;
    $_SESSION["fph"] = $fare;

    // Now you can use $_SESSION["bsnm"] and $_SESSION["fph"] throughout
    echo "Bus Selected: $bus_name<br>";
    echo "Fare: ₹$fare<br>";
} 
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passenger Info</title>
    <link rel="stylesheet" href="sign-up.css">
</head>

<body>

    <h1>
        <u>Passenger Information</u>
    </h1>
    <img class="bg1" src="https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" alt="bus">

    <div class="container_pssngr_1">
        <?php


        // Get session data
        $a = $_SESSION['frm'] ?? 'Unknown';
        $b = $_SESSION['to'] ?? 'Unknown';
        $c = $_SESSION['dt'] ?? 'Unknown';

        // Get posted data or use fallback
        $radio_name = $_POST['radio_name'] ?? 'red bus';
        $fair_name = $_POST['fair_name'] ?? '500';

        // Display info
        echo "From: " . $a . "<br><br><br>";
        echo "To: " . $b . "<br><br><br>";
        echo "Date: " . $c . "<br><br><br>";
        echo "Bus Name: " . $radio_name . "<br><br><br>";
        echo "Bus Fare: " . $fair_name . "<br><br><br>";

        // Save to session for next step
        $_SESSION["fph"] = $fair_name;
        $_SESSION["bsnm"] = $radio_name;
        ?>
    </div>

    <form action="payment page.php" method="post" onsubmit="return validate()">
        <script>
            var d, count = 1;

            function addrw() {
                d = document.getElementById("num_id").value;
                var mytab = document.getElementById("t1");
                var v;
                if (count <= d) {
                    v = 1;
                    while (count <= d) {
                        var r1 = mytab.insertRow();
                        var c1 = r1.insertCell();
                        var c2 = r1.insertCell();
                        var c3 = r1.insertCell();
                        var c4 = r1.insertCell();

                        c1.innerHTML = v;
                        c2.innerHTML = "<input type='text' name='col2_" + v + "' required>";
                        c3.innerHTML = "<input type='text' name='col3_" + v + "' id='col3" + v + "' required>";
                        c4.innerHTML = "<input type='text' name='col4_" + v + "' required>";
                        count++;
                        v++;
                    }
                } else {
                    alert("No number has been entered");
                }
                return false;
            }

            function delrw() {
                var c = document.getElementById("num_id").value;
                document.getElementById("t1").deleteRow(c);
                c = c - 1;
                document.getElementById("num_id").value = c;
            }

            function validate() {
                var i, s;
                for (i = 1; i <= d; i++) {
                    s = document.getElementById("col3" + i).value;
                    if (isNaN(s)) {
                        alert("Please enter a valid number");
                        return false;
                    }
                }
                return true;
            }
        </script>

        <div class="container_pssngr_2">
            Number of passengers: <input type="number" id="num_id" name="num_name" required><br><br>
            <input type="button" value="GET ROWS" id="gtrws_id" onclick="addrw()">
            <br><br>
            <table id="t1">
                <tr>
                    <td>SL No.</td>
                    <td>Passenger name</td>
                    <td>Contact number</td>
                    <td>Age</td>
                </tr>
            </table>
            <br><br>
            <input type="button" value="DELETE ROW" id="delrw_id" onclick="delrw()">
            <br><br><br>
            <input type="submit" class="btn_pssngr" value="Go to payment details">
        </div>
    </form>

</body>
</html>